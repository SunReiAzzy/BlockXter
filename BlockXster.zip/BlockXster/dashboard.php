<?php
$change = '';
// Importation des configurations
include_once ('inc/commons.php');

require_once('inc/PDOConnect.php');
require_once('inc/User.php');
require_once('inc/SessionManagment.php');

$_SESSION["message"] = '';

// Détection du cookie 'user' confirmant la connexion d'un utilisateur
if(isset($_COOKIE['user'])) {
    // Affichage des éléments disponibles seulement après connexion
    $change = "<script>document.getElementById('signin').style.display = 'none';
    document.getElementById('signup').style.display = 'none';
    document.getElementById('signout').style.display = 'block';
    document.getElementById('profile').style.display = 'block';</script>";
    // Affichage des informations disponibles
    // $info = "Info: ".$_SESSION["lname"]." ".$_SESSION["fname"]." - ".$_SESSION["bdate"]." - ".$_SESSION["usage"]." ans";
    // Si l'admin est connecté
    if ($_COOKIE['user'] == 1)
        // Affichage du tableau de bord
        $change .= "<script>document.getElementById('dashboard').style.display = 'block';</script>";
    // Sinon
    else
        // Masquer le tableau de bord
        $change .= "<script>document.getElementById('dashboard').style.display = 'none';</script>";
}

// Détection de 'nouser' dans l'adresse URL confirmant la déconnexion d'un utilisateur et du cookie 'user'
if (isset($_GET['nouser']) && isset($_COOKIE['user']))
    // Déconnexion de l'utilisateur
    Disconnect();

// Si 'nouser' est détecté alors que le cookie 'user' n'a pas été créé ('nouser' a été tapé manuellement dans la barre de recherche ou l'utilisateur a accédé au bouton "Déconnexion" sans avoir été permis)
if (isset($_GET['nouser']) && !(isset($_COOKIE['user'])))
    // Redirection vers la page d'accueil
    header('location: index.php');

// Connexion
$bdd = new PDO('mysql:host=localhost; dbname=mediatheque', 'root', '');
if (isset($_POST['add'])) {
	$query = $bdd->prepare("SELECT titre, phone FROM users WHERE email = ? OR phone = ?");
        $query->execute([
            $email,
            $phone
        ]);
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if ($query->rowCount()) {
            return 0;
        } else {
            $query = $pdo->pdo_start()->prepare("INSERT INTO `users`(`nom`, `prenom`, `psswd`, `birth`, `postal`, `email`, `phone`, `role`) VALUES (?,?,?,?,?,?,?,'M')");
            $query->execute([
                $nom,
                $prenom,
                $psswd,
                $birth,
                $postal,
                $email,
                $phone
            ]);
            return 1;
        }
} elseif (isset($_POST['edit'])) {
	# code...
} elseif (isset($_POST['remove'])) {
	# code...
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<title>BlockXter</title>
	<meta charset="UTF-8">
	<meta name="description" content="BlockXter">
	<meta name="keywords" content="movie, cinema, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/ticket.ico" rel="shortcut icon"/>

	<!-- Google Font -->   
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/jquery-ui.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	<style>
		/*FORM*/

		.form-style-1 textarea,
		.form-style-1 input{ display: block; width: 100%; padding: 0 20px;  border: 0px; border-bottom: 3px solid transparent; background: #EFF6F7; height: 50px;
		        outline: 0; -webkit-transition: all .2s ease-in;  transition: all .2s ease-in; }

		.form-style-1 textarea:focus,
		.form-style-1 input:focus,
		.form-style-1 textarea:active,
		.form-style-1 input:active{ border-bottom: 3px solid #EF0031; }
		.form-style-1 label{ color: yellow; }

		.placeholder-1 ::-webkit-input-placeholder { font-style: italic; color: #aaa; font-size: .9em;  }
		.placeholder-1 ::-moz-placeholder { font-style: italic; color: #aaa; font-size: .9em; }
		.placeholder-1 :-ms-input-placeholder { font-style: italic; color: #aaa; font-size: .9em;  }
		.placeholder-1 :-moz-placeholder { font-style: italic; color: #aaa; font-size: .9em;  }


		.form-bold input,
		.form-bold textarea {
		        font-weight: 700;
		}

		.form-plr-15 input,
		.form-plr-15 textarea {
		        padding: 0 15px;
		}

		.form-plr-20 input,
		.form-plr-20 textarea {
		        padding: 0 20px;
		}

		.form-h-35 input {
		        height: 35px;
		}

		.form-h-40 input {
		        height: 40px;
		}

		.form-h-45 input {
		        height: 45px;
		}

		.form-h-50 input {
		        height: 50px;
		}

		.form-h-55 input {
		        height: 55px;
		}

		.form-mb-20 input,
		.form-mb-20 textarea {
		        margin-bottom: 20px;
		}

		.form-brdr-grey input,
		.form-brdr-grey textarea {
		        border: 1px solid #ccc;
		}

		.form-brdr-lite-white input,
		.form-brdr-lite-white textarea {
		        border: 1px solid #ddd;
		}

		.form-brdr-b-grey input,
		.form-brdr-b-grey textarea {
		        outline: 0;
		        border: 0px;
		        border-bottom: 1px solid #ccc;
		}

		.form-brdr-b-grey input:focus,
		.form-brdr-b-grey textarea:focus {
		        border-bottom: 1px solid #EF0031;
		}

		.form-brdr-b input,
		.form-brdr-b textarea {
		        outline: 0;
		        background: none;
		        border: 0;
		        border-bottom: 1px solid #ccc;
		}

		.form-bg-white input,
		.form-bg-white textarea {
		        background: #fff;
		        border: 1px solid #eee;
		}

		/* The message box is shown when the user clicks on the password field */
          #message {
              display:none;
              background: #f1f1f1;
              color: #000;
              position: relative;
              padding: 20px;
              margin-top: 10px;
          }

          #message p {
              padding: 10px 35px;
              font-size: 18px;
          }

          /* Add a green text color and a checkmark when the requirements are right */
          .valid {
              color: green;
          }

          .valid:before {
              position: relative;
              left: -35px;
              content: "✔";
          }

          /* Add a red text color and an "x" when the requirements are wrong */
          .invalid {
              color: red;
          }

          .invalid:before {
              position: relative;
              left: -35px;
              content: "✖";
          }
	</style>

</head>
<body>
	<!-- Page Preloder -->
	<!-- <div id="preloder">
		<div class="loader"></div>
	</div> -->
	
	<!-- Header section -->
	<header class="header-section fixed-to">
		<div class="header-warp">
			<!-- Site Logo -->
			<a href="index.php" class="site-logo">
				<img src="img/logox2.png" alt="" style="width: 100px; clip-path: circle(50% at 50% 50%);">
			</a>
			<div style="padding-top: 45px; padding-left: 20px"><i class="fa fa-lg fa-search"></i>&nbsp;
				<form class="form-style-1 placeholder-1" action="search#results" method="GET">
					<input type="text" name="query" placeholder="Rechercher un film" style="width: 160px;" required>
					<input type="submit" value="GO">
				</form>
			</div>
			<ul class="main-menu">
				<li class="active"><a id="dashboard" style="display: none;" href="dashboard.php"><i class="fa fa-lg fa-bars"></i>&nbsp;Dashboard</a></li>
				<li><a id="signout" style="display: none;" href="index.php?nouser=true"><i class="fa fa-lg fa-sign-in"></i>&nbsp;Deconnexion</a></li>
				<!-- <li><a id="profile" style="display: none;" href="profile.php"><i class="fa fa-lg fa-user"></i>&nbsp;<?php echo $_SESSION["info"];?></a></li> -->
			</ul>
			<!-- responsive -->
			<div class="nav-switch">
				<i class="fa fa-bars"></i>
			</div>
			<!-- Main Menu -->
			<ul class="main-menu">
				<li><a href="index.php"><i class="fa fa-lg fa-home"></i>&nbsp;Accueil</a></li>
				<!-- <li><a href="about.php"><i class="fa fa-lg fa-history"></i>&nbsp;Histoire</a></li> -->
				<li><a id="tags" href="tags.php"><i class="fa fa-lg fa-pie-chart"></i>&nbsp;Categories</a></li>
				<li><a href="movies.php"><i class="fa fa-lg fa-play"></i>&nbsp;Films</a></li>
				<!-- <li><a href="news.php"><i class="fa fa-lg fa-book"></i>&nbsp;News</a></li> -->
				<li><a href="contact.php"><i class="fa fa-lg fa-phone"></i>&nbsp;Contact</a></li>
				<li><a id="signin" href="signin.php"><i class="fa fa-lg fa-sign-in"></i>&nbsp;Se connecter</a></li>
                <li id="signup"><a href="signup.php"><i class="fa fa-lg fa-user"></i>&nbsp;S'inscrire</a></li>
                
                
			</ul>
			<div class="clearfix"></div>
			    
			</div><!-- container -->
			<!-- Social Links -->
			<!-- <div class="header-social-links">
				<a href="https://twitter.com/"><i class="fa fa-twitter"></i></a>
				<a href="https://soundcloud.com/"><i class="fa fa-soundcloud"></i></a>
				<a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
				<a href="https://plus.google.com/"><i class="fa fa-google-plus"></i></a>
				<a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
				<a href="https://www.youtube.com/"><i class="fa fa-youtube-play"></i></a>
			</div> -->
		</div>
	</header>
	<!-- Header section end -->


	<!--  section -->
	<!-- <section class="page-info-section set-bg" data-setbg="img/page-info-bg.jpg">
		<div class="container">
			<div class="section-title text-center">
				<h2>Elements</h2>	
			</div>
		</div>
	</section> -->
	<!--  section end -->


	<!--  Elements section -->
	<section class="elements-section">
		<div class="container">
			<!-- element -->
			<!-- <div class="element">
				<div class="section-title text-center">
					<h2>Buttons</h2>	
				</div>
				<div class="text-center">
					<a href="" class="site-btn mr-4">SEND IT!</a>
					<a href="" class="site-btn sb-dark mr-4">SEND IT!</a>
					<a href="" class="site-btn sb-light mr-4">SEND IT!</a>
					<a href="" class="site-btn sb-line">SEND IT!</a>
				</div>
			</div> -->
			<!-- element -->
			<div class="element">
				<div class="section-title text-center">
					<h2>Paramètres de la médiathèque</h2>	
				</div>
				<div class="row">
					<div class="col-lg-6">
						<!-- Accordions -->
						<div id="accordion" class="accordion-area">
							<div class="panel">
								<div class="panel-header" id="headingOne">
									<button class="panel-link" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapse1">Ajouter un film dans la médiathèque</button>
								</div>
								<div id="collapse1" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
									<div class="panel-body">
										<form class="contact-form form-style-1 placeholder-1" action="dashboard.php" method="post">
											<div class="row">
												<div class="col-lg-4">
													<input type="text" placeholder="Titre" name="titre1">
												</div>
												<div class="col-lg-4">
													<input type="text" placeholder="Durée" name="duree1">
												</div>
												<div class="col-lg-4">
													<input type="text" placeholder="Réalisateur" name="realisateur1">
												</div>
												<div class="col-lg-12">
													<textarea placeholder="Résumé" name="resume1"></textarea>
													<div class="text-center">
														<input style="background-color: green" class="site-btn" value="Ajouter" type="submit" name="add">
														<!-- <button class="site-btn">Ajouter</button> -->
													</div>
												</div>	
											</div>
										</form>
									</div>
								</div>
							</div>
							<div class="panel">
								<div class="panel-header" id="headingTwo">
									<button class="panel-link" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapse2">Modifier un film de la médiathèque</button>
								</div>
								<div id="collapse2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
									<div class="panel-body">
										<form class="contact-form form-style-1 placeholder-1" action="dashboard.php" method="post">
											<div class="row">
												<div class="col-lg-4">
													<input type="text" placeholder="Titre" name="titre2">
												</div>
												<div class="col-lg-4">
													<input type="text" placeholder="Durée" name="duree2">
												</div>
												<div class="col-lg-4">
													<input type="text" placeholder="Réalisateur" name="realisateur2">
												</div>
												<div class="col-lg-12">
													<textarea placeholder="Résumé" name="resume2"></textarea>
													<div class="text-center">
														<input style="background-color: cyan" class="site-btn" value="Modifier" type="submit" name="edit">
														<!-- <button class="site-btn">Modifier</button> -->
													</div>
												</div>	
											</div>
										</form>
									</div>
								</div>
							</div>
							<div class="panel">
								<div class="panel-header active" id="headingThree">
									<button class="panel-link active" data-toggle="collapse" data-target="#collapse3" aria-expanded="true" aria-controls="collapse3">Supprimer un film de la médiathèque</button>
								</div>
								<div id="collapse3" class="collapse show" aria-labelledby="headingThree" data-parent="#accordion">
									<div class="panel-body">
										<form class="contact-form form-style-1 placeholder-1" action="dashboard.php" method="post">
											<div class="row">
												<div class="col-lg-4">
													<input type="text" placeholder="" disabled style="visibility: hidden;">
												</div>
												<div class="col-lg-4">
													<input type="text" placeholder="Titre" name="titre3">
												</div>
												<div class="col-lg-4">
													<input type="text" placeholder="" disabled style="visibility: hidden;">
												</div>
												<div class="col-lg-12">
													<div class="text-center">
														<input style="background-color: red" class="site-btn" value="Supprimer" type="submit" name="delete">
														<!-- <button class="site-btn">Modifier</button> -->
													</div>
												</div>	
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<!-- Tabs -->
						<div class="tab-element">
							<ul class="nav nav-tabs" id="myTab" role="tablist">
								<li class="nav-item">
									<a class="nav-link active" id="1-tab" data-toggle="tab" href="#tab-1" role="tab" aria-controls="tab-1" aria-selected="true">Films</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" id="2-tab" data-toggle="tab" href="#tab-2" role="tab" aria-controls="tab-2" aria-selected="false">Catégories</a>
								</li>
								<li class="nav-item">
									<a class="nav-link" id="3-tab" data-toggle="tab" href="#tab-3" role="tab" aria-controls="tab-3" aria-selected="false">Trailers</a>
								</li>
							</ul>
							<div class="tab-content" id="myTabContent">
								<!-- single tab content -->
								<div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab-1">
									<p>Aquaman (2018) - Venom (2018) - Bumblebee (2018)<br>COMING SOON: Spiderman Into The Spiderverse (2018) - Captain Marvel (2019)</p>
								</div>
								<div class="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="tab-2">
									<p>Aquaman (2018): AC-FA-FF-HU<br>Venom (2018): AC-HU-HO-SF<br>Bumblebee (2018): AC-FA-HU-SF</p>
								</div>
								<div class="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="tab-3">
									<p>Aquaman (2018): 1 trailer<br>Venom (2018): 2 trailers<br>Bumblebee (2018): 1 trailer</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- element -->
			<!-- <div class="element">
				<div class="section-title text-center">
					<h2>Loaders</h2>	
				</div>
				<div class="row">
					<div class="col-lg-3 col-sm-6 cp-item">
						<div class="circle-progress" data-cptitle="Liseners" data-cpid="id-1" data-cpvalue="85" data-cpcolor="#ffe400"></div>
					</div>
					<div class="col-lg-3 col-sm-6 cp-item">
						<div class="circle-progress" data-cptitle="Love" data-cpid="id-2" data-cpvalue="100" data-cpcolor="#ffe400"></div>
					</div>
					<div class="col-lg-3 col-sm-6 cp-item">
						<div class="circle-progress" data-cptitle="Liseners" data-cpid="id-3" data-cpvalue="95" data-cpcolor="#ffe400"></div>
					</div>
					<div class="col-lg-3 col-sm-6 cp-item">
						<div class="circle-progress" data-cptitle="International" data-cpid="id-4" data-cpvalue="25" data-cpcolor="#ffe400"></div>
					</div>
				</div>
			</div> -->
			<!-- element -->
			<!-- <div class="element">
				<div class="section-title text-center">
					<h2>Milestones</h2>	
				</div>
				<div class="row">
					<div class="col-lg-3 col-sm-6 fact">
						<img src="img/facts/1.png" alt="">
						<p>Followers</p>
					</div>
					<div class="col-lg-3 col-sm-6 fact">
						<img src="img/facts/2.png" alt="">
						<p>Liseners</p>
					</div>
					<div class="col-lg-3 col-sm-6 fact">
						<img src="img/facts/3.png" alt="">
						<p>Radio Station</p>
					</div>
					<div class="col-lg-3 col-sm-6 fact">
						<img src="img/facts/4.png" alt="">
						<p>Dj’s</p>
					</div>
				</div>
			</div> -->
			<!-- element -->
			<!-- <div class="element">
				<div class="section-title text-center">
					<h2>Icon Boxes</h2>	
				</div>
				<div class="row">
					<div class="col-lg-4 icon-boxe">
						<i class="flaticon-gamepad-with-joystick"></i>
						<h4>Where?</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu  tincidunt ligula. Fusce dictum ullamcorper purus, at elementum sem sollicit udin non. Sed id tristique lacus. Fusce pellentesque dignissim arcu, id hendrerit urna feugiat vitae. Pellentesque viverra aliquet arcu,  aliquet est commodo quis. Nam tempus, nisl eu maximus viverra, magna quam porta nibh.</p>
						<a href="" class="readmore">MORE INFO</a>
					</div>
					<div class="col-lg-4 icon-boxe">
						<i class="flaticon-film-roll"></i>
						<h4>Where?</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu  tincidunt ligula. Fusce dictum ullamcorper purus, at elementum sem sollicit udin non. Sed id tristique lacus. Fusce pellentesque dignissim arcu, id hendrerit urna feugiat vitae. Pellentesque viverra aliquet arcu,  aliquet est commodo quis. Nam tempus, nisl eu maximus viverra, magna quam porta nibh.</p>
						<a href="" class="readmore">MORE INFO</a>
					</div>
					<div class="col-lg-4 icon-boxe">
						<i class="flaticon-jazz-saxophone"></i>
						<h4>Where?</h4>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu  tincidunt ligula. Fusce dictum ullamcorper purus, at elementum sem sollicit udin non. Sed id tristique lacus. Fusce pellentesque dignissim arcu, id hendrerit urna feugiat vitae. Pellentesque viverra aliquet arcu,  aliquet est commodo quis. Nam tempus, nisl eu maximus viverra, magna quam porta nibh.</p>
						<a href="" class="readmore">MORE INFO</a>
					</div>
				</div>
			</div> -->
		</div>
	</section>
	<!--  Elements section end -->


	<!-- Footer Top section -->
	<section class="footer-top-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6 ft-widget">
					<div class="ft-title">
						<h4>Catégories</h4>
					</div>
					<ul class="order-list">
						<li><a href="tags.php?tagid=6"><span>AC</span>Action</a></li>
						<li><a href="tags.php?tagid=5"><span>FA</span>Famille</a></li>
						<li><a href="tags.php?tagid=2"><span>FF</span>Fantaisie</a></li>
						<li><a href="tags.php?tagid=4"><span>HO</span>Horreur</a></li>
						<li><a href="tags.php?tagid=3"><span>HU</span>Humour</a></li>
						<li><a href="tags.php?tagid=1"><span>SF</span>Science-Fiction</a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-6 ft-widget">
					<div class="ft-title">
						<h4>Top Films</h4>
					</div>
					<ul class="order-list">
						<li><a href="movies.php?filmid=1"><span>1</span>Aquaman</a></li>
						<li><a href="movies.php?filmid=2"><span>2</span>Venom</a></li>
						<li><a href="movies.php?filmid=3"><span>3</span>Bumblebee</a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-6 ft-widget">
					<div class="ft-title">
						<h4>News</h4>
					</div>
					<div class="ft-blog-widget">
						<div class="bw-item">
							<div class="bw-thumb set-bg" data-setbg="img/blog/thumb/1.jpg"></div>
							<div class="bw-content">
								<p>Films DC & Marvel</p>
								<a href="news.php">Lire plus</a>
							</div>
						</div>
						<div class="bw-item">
							<div class="bw-thumb set-bg" data-setbg="img/blog/thumb/2.jpg"></div>
							<div class="bw-content">
								<p>Coups de coeur et coups de gueule</p>
								<a href="news.php">Lire plus</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 ft-widget">
					<div class="ft-title">
						<h4>Contact</h4>
					</div>
					<div class="ft-contact-widget">
						<p><span>A:</span> 23, rue des Médias Film-sur-Scène</p>
						<p><span>T:</span> 06-23-12-1999</p>
						<p><span>E:</span> media@theque.com</p>
						<img src="img/logox2.png" style="width: 100px; clip-path: circle(50% at 50% 50%);">
						<img src="img/logox.png" style="width: 100px; clip-path: circle(50% at 50% 50%);">
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Footer Top section end -->

	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<p><!-- Lien de la template  -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> Tous droits réservés | Site fait avec <i class="fa fa-heart-o" aria-hidden="true"></i> par <a href="https://colorlib.com" target="_blank">MONDESIR Malik</a></p>
		</div>
	</footer>
	<!-- Footer section end -->

	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>
	<?php echo $change; ?>
    </body>
</html>
