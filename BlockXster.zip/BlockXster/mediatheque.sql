-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Mar 08 Janvier 2019 à 10:30
-- Version du serveur: 5.6.12-log
-- Version de PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Base de données: `mediatheque`
--
CREATE DATABASE IF NOT EXISTS `mediatheque` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `mediatheque`;

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ref` varchar(10) COLLATE utf8_bin NOT NULL,
  `lib` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=7 ;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`id`, `ref`, `lib`) VALUES
(1, 'AC', 'Action'),
(2, 'FA', 'Famille'),
(3, 'FF', 'Fantaisie'),
(4, 'HO', 'Horreur'),
(5, 'HU', 'Humour'),
(6, 'SF', 'Science-Fiction');

-- --------------------------------------------------------

--
-- Structure de la table `film`
--  

CREATE TABLE IF NOT EXISTS `film` (
  `id` int(11) NOT NULL,
  `titre` text COLLATE utf8_bin NOT NULL,
  `duree` time NOT NULL,
  `resume` text COLLATE utf8_bin NOT NULL,
  `realisateur` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Contenu de la table `film`
--

INSERT INTO `film` (`id`, `titre`, `duree`, `resume`, `realisateur`) VALUES
(1, 'Aquaman (2018)', '02:22:00', 'En 1985 dans le Maine, le gardien de phare Tom Curry découvre Atlanna, une Atlante blessée, qu''il recueille et soigne. L''homme de la terre et la femme de la mer tombent vite amoureux. De leur amour naît un fils, Arthur. Lorsque les hommes du roi de l''Atlantide retrouvent sa promise Atlanna, celle-ci doit retourner dans son royaume et laisser son fils à Tom, craignant que les Atlantes ne les tuent tous les trois si elle ne revient pas.\r\n\r\n33 ans plus tard, Arthur est devenu Aquaman, après des années d''entraînement avec son mentor Nuidis Vulko (en). Alors qu''il sauve les matelots d''un sous-marin russe, Aquaman se fait un nouvel ennemi, le pirate David Kane, lorsqu''il laisse mourir son père Jesse dans le submersible qui sombre vers les abysses. Il s''avère que les Kane ont été secrètement mandatés par Orm, roi d''Atlantis et demi-frère d''Arthur, pour manipuler le Roi Nérée du royaume de Xebel qu''il veut rallier à son projet d''attaque des hommes de la terre surnommés les Surfaciens. En effet, Orm est excédé par les exactions commises par le monde de la surface sur les océans (pollution, pêche excessive) et a décidé de déclarer la guerre aux Surfaciens. Or pour cela, il lui faut l''appui d''au moins trois autres populations sous-marines, et le seul moyen de les avoir à ses côtés est de rallier le roi Nérée.\r\n\r\nAlors que Vulko et Orm rencontrent Nérée dans un coin reculé de l''océan, ils sont attaqués par un sous-marin surfacien. De nombreux atlantes sont tués dans l''affrontement. C''est ce qu''il fallait pour convaincre Nérée, jusque-là réticent ; il décide dès lors de se joindre à Orm et ils lancent un avertissement au monde de la surface : une vague gigantesque s''abat sur les côtes, rejetant des tonnes de déchets sur les côtes et rendant les plages inutilisables. Arthur en fait les frais : alors qu''il rentrait chez lui avec son père en voiture, la vague s''est abattue sur leur voiture, manquant de noyer son père. Mera, fille du roi Nérée et promise d''Orm, sauve la vie de Tom grâce à ses pouvoirs hydrokinétiques et convainc Arthur de la suivre à Atlantis : en tant que fils aîné de la reine Atlanna, Arthur peut contester le trône à Orm, surtout s''il a en sa possession le trident légendaire du roi Atlan qui a été forgé il y a des millénaires mais perdu depuis la chute d''Atlantis sous l''eau.\r\n\r\nIls se rendent sur Atlantis, mais ils sont capturés par Orm, averti de leur présence. Il provoque Arthur pour qu''il le défie en combat singulier, étant sûr de sa victoire : si Arthur est peu à peu devenu un combattant redoutable en surface grâce à ses capacités, Orm a quant à lui passé toute sa vie sous l''eau et aura l''avantage durant le duel. Rapidement, Orm prend le dessus et Arthur voit son trident brisé pendant le duel ; désormais vulnérable, il est récupéré par Mera, qui l''évacue alors qu''ils sont pourchassés par les gardes atlantes. Nuidis Vulko leur remet, en secret, un plan qui mènerait au trident légendaire, et le duo se rend au Sahara.\r\n\r\nSur place, ils trouvent une antique cité atlante, sur laquelle se trouve un message du roi Atlan, le dernier possesseur du trident, qui leur indique que l''indice suivant qui les mènera au trident se trouve en Sicile. Mais sur place, ils sont confrontés à Kane, qui se fait désormais appeler Black Manta. Muni d''armes atlantes par Orm, il est toujours farouchement décidé à venger la mort de son père. Au terme d''un violent combat sur les toits des maisons siciliennes, Manta semble tué, mais Arthur a subi plusieurs blessures. Mera qui s''est entretemps défaite de ses assaillants, le soigne et l''emmène à leur prochaine étape.\r\n\r\nIl s''agit du CÅ“ur de l''Océan, une mer secrète dissimulée derrière une chute d''eau sous-marine et cachée aux yeux de tous au fond du royaume de la Fosse, peuplée de créatures marines difformes. Sur place, Arthur et Mera réalisent, stupéfaits, qu''Atlanna est en réalité vivante. À son retour en Atlantis, elle avait été condamnée à mort pour avoir enfanté Arthur et condamnée à mourir dans cette zone, mais elle a réussi à survivre. Elle leur apprend également que le trident se trouve dans les lieux, gardé par le Karaten, un monstre redoutable qui ne laissera passer que le roi légitime. En dépit du risque, Arthur se présente devant le Karaten ; au début hostile, ce dernier le laisse prendre le sceptre et lui permet de repartir en voyant qu''il peut communiquer avec les animaux marins tels que lui.\r\n\r\nArthur et Mera rejoignent le champ de bataille sur lequel s''affrontent Orm et une autre race sous-marine qu''il souhaite soumettre pour en faire son alliée. Grâce à sa capacité à communiquer à toute forme de vie sous-marine amplifiée par le trident, Arthur défait une grande partie des animaux utilisés par Orm et effraie ses hommes. Il reprend ensuite son duel face à Orm et cette fois-ci, le vainc, utilisant à la fois son nouveau trident et appliquant les leçons de Vulko une fois le combat amené hors de l''eau. Alors que son frère demande qu''il l''achève, Atlanna intervient et demande que cessent les tueries. Aquaman est désormais roi de plein droit et s''est rapproché de Mera, tandis qu''Atlanna rejoint Tom après 20 ans d''absence.', 'James Wan'),
(2, 'Venom (2018)', '02:20:00', 'Lors d''une expédition d''exploration, un vaisseau spatial de la Life Foundation (en) retourne sur Terre avec à son bord quatre échantillons de symbiotes extraterrestres. Mais durant l''entrée dans l''atmosphère terrestre, le vaisseau connaît une avarie et s''écrase dans l''est de la Malaisie. Depuis son immense complexe à San Francisco, le savant Carlton Drake, puissant et mystérieux PDG de la fondation, gère les opérations. Il parvient à faire rapatrier trois des quatre échantillons. Le quatrième s''est enfui en prenant possession d''un corps.\r\n\r\nÀ San Francisco, le journaliste Eddie Brock est chargé d''interviewer Carlton Drake, après de nombreuses rumeurs prétendant que la Life Foundation utilise des cobayes humains. Eddie trouve des éléments dans les dossiers de sa fiancée, Anne Weying, avocate dont le cabinet collabore étroitement avec la Life Foundation. Mais en accusant publiquement Drake de tuer ses cobayes sans apporter de preuve formelle, il est renvoyé de son journal et perd en même temps sa fiancée et son appartement.\r\n\r\nSix mois plus tard, Eddie vit de petits boulots et habite dans un appartement miteux.\r\n\r\nPendant ce temps, Drake conduit des expériences d''union entre les symbiotes et des hôtes animaux, puis humains, entraînant la mort de ses cobayes. Choquée, l''une de ses collaboratrices, Dora Skirth, contacte Eddie et le fait pénétrer dans le laboratoire. Le journaliste est infecté par l''un des symbiotes qui va petit à petit prendre le contrôle de son corps et de son esprit.\r\n\r\nPoursuivi par les hommes de main de Drake, Eddie comprend qu''un être extraterrestre portant le nom de Venom a pris le contrôle de son corps. Cet être, qui dialogue avec lui, possède une force gigantesque et peut transformer son corps pour résister aux balles, créer différents projectiles ou escalader des gratte-ciels. Venom est très souvent affamé et il lui arrive de dévorer ses poursuivants.\r\n\r\nPeu à peu Eddie et Venom apprennent à cohabiter et Venom, qui voulait au départ utiliser une fusée de Drake pour aller chercher ses congénères, décide de rester sur Terre.\r\n\r\nTous deux combattent finalement Drake, désormais habité par Riot, le symbiote qui s''était échappé en Malaisie, les deux symbiotes restants dans le laboratoire étant morts. Tandis que Drake et Riot tentent de s''enfuir à bord d''une fusée pour aller chercher le peuple des symbiotes qui fusionnera avec l''humanité, Venom dans le corps d''Eddie, aidé par l''ex-fiancée de ce dernier, réussit à les arrêter en les faisant périr dans l''explosion de la fusée.\r\n\r\nQuelques jours plus tard, Eddie récupère son travail de journaliste, après avoir montré les preuves relatives à Drake. Il annonce à Venom qu''il ne devra faire désormais du mal qu''aux méchants. Alors qu''ils font les courses dans une épicerie, Venom tue un racketteur qu''Eddie avait laissé échapper avant d''acquérir ses pouvoirs. Le film se termine lorsque Venom dit à Eddie qu''ils peuvent faire tout ce qu''ils veulent.\r\n\r\nScène à mi-générique : Eddie Brock va interviewer le tueur en série Cletus Kassady dans une prison de haute sécurité. Le prisonnier lui annonce qu''il sortira un jour et qu''il y aura alors un « carnage ».\r\n\r\nLongue scène post-générique animée, annonçant Spider-Man: New Generation1 : dans un autre monde, un adolescent déguisé en Spiderman échappe à un motard masqué et se retrouve dans un cimetière enneigé où il se recueille sur la tombe de son modèle Peter Parker. Or un homme inanimé, qui ressemble à Parker et du corps duquel jaillit du fil d''araignée, tombe à côté de lui ; en voulant le sauver de ses poursuivants, l''adolescent se retrouve embarqué dans une spectaculaire course accroché à une rame de métro.', 'Ruben Fleischer'),
(3, 'Bumblebee (2018)', '01:54:00', 'Vingt ans avant les événements du premier film transformers, en 1987, dans une ville balnéaire californienne. Alors que la guerre a pris une tournure critique sur la planète Cybertron, l''Autobot B-127 est envoyé sur Terre par son chef Optimus Prime afin de préparer un refuge et de protéger les humains d''une éventuelle attaque de leurs ennemis, les Decepticons. Fortement endommagé et son synthétiseur vocal détruit au cours d''un combat contre Blitzwing, B-127 échappe à une troupe militaire et échoue sur une plage, où il se transforme en Volkswagen Coccinelle jaune, avant de se désactiver. A la veille de son 18ème anniversaire, Charlie Watson trouve B-127 dans la casse de son oncle Hank. En tentant une réparation dans son garage, elle découvre qu''il ne s''agit pas d''une simple voiture et décide de surnommer le robot BumbleBee. L''Autobot est repéré par Dropkick et Shatter, deux Decepticons lancés à sa recherche, lorsque Charlie allume sa radio. Accueillis par les hommes du Secteur 7, les Decepticons dépeignent l''Autobot comme un criminel et demandent la permission d''utiliser le réseau de satellites pour le retrouver. Charlie et son voisin Guillermo « Memo » Gutierrez se retrouvent impliqués malgré eux dans la dangereuse chasse qui s''ensuit…', 'Travis Knight');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(30) COLLATE utf8_bin NOT NULL,
  `psswd` varchar(30) COLLATE utf8_bin NOT NULL,
  `birth` date NOT NULL,
  `postal` text COLLATE utf8_bin NOT NULL,
  `email` varchar(50) COLLATE utf8_bin NOT NULL,
  `phone` varchar(10) COLLATE utf8_bin NOT NULL,
  `role` char(1) COLLATE utf8_bin NOT NULL,
  `user_reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id`, `nom`, `prenom`, `psswd`, `birth`, `postal`, `email`, `phone`, `role`, `user_reg_date`) VALUES
(1, 'Media', 'Theque', 'root', '1999-12-23', '23 rue des Medias, 95 023 Film-sur-Scene', 'media@theque.com', '0123121999', 'A', '2019-01-08 10:11:12');
