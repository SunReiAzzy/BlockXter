<?php
session_start();
try
{
    $mysqli = new mysqli('localhost', 'root', '');
}
catch (\Exception $e)
{
    echo $e->getMessage(), PHP_EOL;
}

if ($mysqli->select_db('mediatheque') === false)
    $database = false;
else
    $database = true;

// Connexion
$bdd = new PDO('mysql:host=localhost', 'root', '');
$bdd->setAttribute(PDO::MYSQL_ATTR_INIT_COMMAND, "SET NAMES 'utf8'");
// Création de la base de donnéees 'mediatheque' à moins qu'elle n'existe ou plutôt si elle n'existe pas
$sql = "CREATE DATABASE IF NOT EXISTS mediatheque CHARACTER SET 'utf8';";
// Aucun retour de résultat
$bdd->exec($sql);
if (!($database)) {
    echo "<script>alert('Database just created');</script>";
    Import();
}
// Déconnexion
$bdd = null;

function Import()
{
    // Importation des tables de la base 'mediatheque'
    $filename = 'mediatheque.sql';

    // Connexion
    $bdd = new PDO('mysql:host=localhost; dbname=mediatheque', 'root', '');
    // Variable temporaire stockant la requête (ligne par ligne)
    $templine = '';
    // Lecture entière du fichier
    $lines = file($filename);
    // Boucle à travers chaque ligne
    foreach ($lines as $line){
        // Passage à la ligne suivante si c'est un commentaire (sauf les commentaires de ce type : '/* */')
        if (substr($line, 0, 2) == '--' || $line == '')
            continue;

        // Ajout ou concaténation de la ligne au segment actuel
        $templine .= $line;
        // Détection de fin de ligne avec le point-virgule
        if (substr(trim($line), -1, 1) == ';')
        {
            // Exécution de la requête
            $bdd->exec($templine);
            // Réinitialisation de la variable temporaire
            $templine = '';
        }
    }
    // Déconnexion
    $bdd = null;
}

// Connexion
$bdd = new PDO('mysql:host=localhost; dbname=mediatheque', 'root', '');
// Insertion d'un compte admin à titre d'exemple
$sql = "INSERT IGNORE INTO users VALUES ('1', 'Media', 'Theque', 'root', '1999-12-23', '23 rue des Medias, 95 023 Film-sur-Scene', 'media@theque.com', '0123121999', 'A', CURRENT_TIMESTAMP);";
// Aucun retour de résultat
$bdd->exec($sql);
// Déconnexion
$bdd = null;

// // Détection du cookie 'user' confirmant la connexion d'un utilisateur
// if(isset($_COOKIE['user']) && isset($_SESSION["lname"]) && isset($_SESSION["fname"]) && isset($_SESSION["bdate"]) && isset($_SESSION["usage"])) {
//     // Affichage des éléments disponibles seulement après connexion
//     $change = "<script>document.getElementById('signin').style.display = 'none';
//     document.getElementById('signup').style.display = 'none';
//     document.getElementById('signout').style.display = 'block';
//     document.getElementById('profile').style.display = 'block';</script>";
//     // Affichage des informations disponibles
//     $info = "Info: ".$_SESSION["lname"]." ".$_SESSION["fname"]." - ".$_SESSION["bdate"]." - ".$_SESSION["usage"]." ans";
//     // Si l'admin est connecté
//     if ($_COOKIE['user'] == 1)
//         // Affichage du tableau de bord
//         $change .= "<script>document.getElementById('dashboard').style.display = 'block';</script>";
//     // Sinon
//     else
//         // Masquer le tableau de bord
//         $change .= "<script>document.getElementById('dashboard').style.display = 'none';</script>";
// }

// function Disconnect() {
//     // Date d'expiration du cookie 'user' dans le passé
//     setcookie('user', 0, time() - 3600, '/');
//     // "Désactivation" du cookie 'user' en cas de doute
//     unset($_COOKIE['user']);
//     // Date d'expiration du cookie 'PHPSESSID' dans le passé: ce cookie est créé lorsqu'une session a démarré
//     setcookie('PHPSESSID', 0, time() - 3600, '/');
//     // "Désactivation" du cookie 'PHPSESSID' en cas de doute
//     unset($_COOKIE['PHPSESSID']);
//     // Redirection vers la page d'accueil
//     header('location: index.php');
// }

// // Détection de 'nouser' dans l'adresse URL confirmant la déconnexion d'un utilisateur et du cookie 'user'
// if (isset($_GET['nouser']) && isset($_COOKIE['user']))
//     // Déconnexion de l'utilisateur
//     Disconnect();

// // Si 'nouser' est détecté alors que le cookie 'user' n'a pas été créé ('nouser' a été tapé manuellement dans la barre de recherche ou l'utilisateur a accédé au bouton "Déconnexion" sans avoir été permis)
// if (isset($_GET['nouser']) && !(isset($_COOKIE['user'])))
//     // Redirection vers la page d'accueil
//     header('location: index.php');
?>
