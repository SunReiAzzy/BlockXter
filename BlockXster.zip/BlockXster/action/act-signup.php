﻿<?php

require_once('../inc/PDOConnect.php');
require_once('../inc/User.php');

// Vérification qu'aucun utilisateur soit connecté
if(isset($_COOKIE['user'])) {
	echo "<script>alert('Utilisateur déjà connecté');</script>";
    header('location: index.php');

}

    /* Vérification du bon envoi des données */
if (empty($_POST['nom']) OR empty($_POST['prenom']) OR empty($_POST['psswd']) OR empty($_POST['email']) OR empty($_POST['postal']) OR empty($_POST['birth']) OR empty($_POST['phone'])) {
    $_SESSION['message'] = '<h6>Un ou plusieurs champs manquant(s)</h6>';
    header('location: signup.php');
}

$nom = ($_POST['nom']);
$prenom =($_POST['prenom']);
$psswd = ($_POST['psswd']);
$email = ($_POST['email']);
$postal = ($_POST['postal']);
$birth = ($_POST['birth']);
$phone = ($_POST['phone']);

$user = new User();
$register = $user->createUser($nom, $prenom, $psswd, $birth, $postal, $email, $phone);

if($register == 0) {
    $_SESSION['message'] = 'Erreur, email et/ou numéro de téléphone déjà utilisé(s).';
    header('location: ../signup.php');
} else {
    $_SESSION['message'] = '<h6>Inscription réussie</h6>';
    header('location: ../signin.php');
}

?>
