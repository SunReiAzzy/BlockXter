﻿<?php

require_once('../inc/PDOConnect.php');
require_once('../inc/User.php');
require_once('../inc/SessionManagment.php');

if(isset($_COOKIE['user'])) {

    $_SESSION['message'] = '<h6>Déjà connecté</h6>';
    header('location: ../index.php');

} else {
    $email = ($_POST['email']);
    $psswd = ($_POST['psswd']);

    $pdo = new PDOConnect();

    $query = $pdo->pdo_start()->prepare("SELECT * FROM users WHERE email = ? AND psswd = ?");
    $query->execute([
        $email,
        $psswd
    ]);
    $result = $query->fetch(PDO::FETCH_ASSOC);

    if ($query->rowCount() == 1) {
        $_SESSION['message'] = 'Connecté';
        setcookie('user', $result['id'], time() + 86400*10, '/');
        $_SESSION["lname"] = $result['nom'];
        $_SESSION["fname"] = $result['prenom'];
        $_SESSION["bdate"] = $result['birth'];
        //date in mm/dd/yyyy format; or it can be in other formats as well
        $birthDate = "1999/12/23";
        //explode the date to get month, day and year
        $birthDate = explode("/", $birthDate);
        //get age from date or birthdate
        $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[1], $birthDate[2], $birthDate[0]))) > date("md")
        ? ((date("Y") - $birthDate[0]) - 1)
        : (date("Y") - $birthDate[0]));
        $_SESSION["usage"] = $age;

        $pdo->pdo_close();
        header('location: ../index.php');

    } else {
        $_SESSION['message'] = 'Erreur de connexion';
        $pdo->pdo_close();
        header('location: ../signin.php');
    }
}
?>
