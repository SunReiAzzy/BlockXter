<?php

require_once('inc/PDOConnect.php');
require_once('inc/User.php');
require_once('inc/SessionManagment.php');
$change = '';
$_SESSION["message"] = '';

// Connexion
$bdd = new PDO('mysql:host=localhost; dbname=mediatheque', 'root', '');

// Détection du cookie 'user' confirmant la connexion d'un utilisateur
if(isset($_COOKIE['user'])) {
    // Affichage des éléments disponibles seulement après connexion
    $change = "<script>document.getElementById('signin').style.display = 'none';
    document.getElementById('signup').style.display = 'none';
    document.getElementById('signout').style.display = 'block';
    document.getElementById('profile').style.display = 'block';</script>";
    // Affichage des informations disponibles
    // $info = "Info: ".$_SESSION["lname"]." ".$_SESSION["fname"]." - ".$_SESSION["bdate"]." - ".$_SESSION["usage"]." ans";
    // Si l'admin est connecté
    if ($_COOKIE['user'] == 1)
        // Affichage du tableau de bord
        $change .= "<script>document.getElementById('dashboard').style.display = 'block';</script>";
    // Sinon
    else
        // Masquer le tableau de bord
        $change .= "<script>document.getElementById('dashboard').style.display = 'none';</script>";
}

function Disconnect() {
    // Date d'expiration du cookie 'user' dans le passé
    setcookie('user', 0, time() - 3600, '/');
    // "Désactivation" du cookie 'user' en cas de doute
    unset($_COOKIE['user']);
    // Date d'expiration du cookie 'PHPSESSID' dans le passé: ce cookie est créé lorsqu'une session a démarré
    setcookie('PHPSESSID', 0, time() - 3600, '/');
    // "Désactivation" du cookie 'PHPSESSID' en cas de doute
    unset($_COOKIE['PHPSESSID']);
    // Redirection vers la page d'accueil
    header('location: index.php');
}

// Détection de 'nouser' dans l'adresse URL confirmant la déconnexion d'un utilisateur et du cookie 'user'
if (isset($_GET['nouser']) && isset($_COOKIE['user']))
    // Déconnexion de l'utilisateur
    Disconnect();

// Si 'nouser' est détecté alors que le cookie 'user' n'a pas été créé ('nouser' a été tapé manuellement dans la barre de recherche ou l'utilisateur a accédé au bouton "Déconnexion" sans avoir été permis)
if (isset($_GET['nouser']) && !(isset($_COOKIE['user'])))
    // Redirection vers la page d'accueil
    header('location: index.php');
?>
 
<!DOCTYPE html>
<html lang="fr">
<head>
	<title>BlockXter</title>
	<meta charset="UTF-8">
	<meta name="description" content="BlockXter">
	<meta name="keywords" content="movie, cinema, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->   
	<link href="img/ticket.ico" rel="shortcut icon"/>

	<!-- Google Font -->   
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/jquery-ui.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/owl.carousel.css"/>
	<link rel="stylesheet" href="css/style.css"/>
	<link rel="stylesheet" href="css/animate.css"/>


	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	<style>
		/*FORM*/

		.form-style-1 textarea,
		.form-style-1 input{ display: block; width: 100%; padding: 0 20px;  border: 0px; border-bottom: 3px solid transparent; background: #EFF6F7; height: 50px;
		        outline: 0; -webkit-transition: all .2s ease-in;  transition: all .2s ease-in; }

		.form-style-1 textarea:focus,
		.form-style-1 input:focus,
		.form-style-1 textarea:active,
		.form-style-1 input:active{ border-bottom: 3px solid #EF0031; }
		.form-style-1 label{ color: yellow; }

		.placeholder-1 ::-webkit-input-placeholder { font-style: italic; color: #aaa; font-size: .9em;  }
		.placeholder-1 ::-moz-placeholder { font-style: italic; color: #aaa; font-size: .9em; }
		.placeholder-1 :-ms-input-placeholder { font-style: italic; color: #aaa; font-size: .9em;  }
		.placeholder-1 :-moz-placeholder { font-style: italic; color: #aaa; font-size: .9em;  }


		.form-bold input,
		.form-bold textarea {
		        font-weight: 700;
		}

		.form-plr-15 input,
		.form-plr-15 textarea {
		        padding: 0 15px;
		}

		.form-plr-20 input,
		.form-plr-20 textarea {
		        padding: 0 20px;
		}

		.form-h-35 input {
		        height: 35px;
		}

		.form-h-40 input {
		        height: 40px;
		}

		.form-h-45 input {
		        height: 45px;
		}

		.form-h-50 input {
		        height: 50px;
		}

		.form-h-55 input {
		        height: 55px;
		}

		.form-mb-20 input,
		.form-mb-20 textarea {
		        margin-bottom: 20px;
		}

		.form-brdr-grey input,
		.form-brdr-grey textarea {
		        border: 1px solid #ccc;
		}

		.form-brdr-lite-white input,
		.form-brdr-lite-white textarea {
		        border: 1px solid #ddd;
		}

		.form-brdr-b-grey input,
		.form-brdr-b-grey textarea {
		        outline: 0;
		        border: 0px;
		        border-bottom: 1px solid #ccc;
		}

		.form-brdr-b-grey input:focus,
		.form-brdr-b-grey textarea:focus {
		        border-bottom: 1px solid #EF0031;
		}

		.form-brdr-b input,
		.form-brdr-b textarea {
		        outline: 0;
		        background: none;
		        border: 0;
		        border-bottom: 1px solid #ccc;
		}

		.form-bg-white input,
		.form-bg-white textarea {
		        background: #fff;
		        border: 1px solid #eee;
		}

		/* The message box is shown when the user clicks on the password field */
          #message {
              display:none;
              background: #f1f1f1;
              color: #000;
              position: relative;
              padding: 20px;
              margin-top: 10px;
          }

          #message p {
              padding: 10px 35px;
              font-size: 18px;
          }

          /* Add a green text color and a checkmark when the requirements are right */
          .valid {
              color: green;
          }

          .valid:before {
              position: relative;
              left: -35px;
              content: "✔";
          }

          /* Add a red text color and an "x" when the requirements are wrong */
          .invalid {
              color: red;
          }

          .invalid:before {
              position: relative;
              left: -35px;
              content: "✖";
          }
	</style>

</head>
<body>
	<!-- Page Preloder -->
	<!-- <div id="preloder">
		<div class="loader"></div>
	</div> -->
	
	<!-- Header section -->
	<header class="header-section fixed-to">
		<div class="header-warp">
			<!-- Site Logo -->
			<a href="index.php" class="site-logo">
				<img src="img/logox2.png" alt="" style="width: 100px; clip-path: circle(50% at 50% 50%);">
			</a>
			<div style="padding-top: 45px; padding-left: 20px"><i class="fa fa-lg fa-search"></i>&nbsp;
				<form class="form-style-1 placeholder-1" action="search#results" method="GET">
					<input type="text" name="query" placeholder="Rechercher un film" style="width: 160px;" required>
					<input type="submit" value="GO">
				</form>
			</div>
			<ul class="main-menu">
				<li><a id="dashboard" style="display: none;" href="dashboard.php"><i class="fa fa-lg fa-bars"></i>&nbsp;Dashboard</a></li>
				<li><a id="signout" style="display: none;" href="index.php?nouser=true"><i class="fa fa-lg fa-sign-in"></i>&nbsp;Deconnexion</a></li>
				<!-- <li><a id="profile" style="display: none;" href="profile.php"><i class="fa fa-lg fa-user"></i>&nbsp;<?php echo $_SESSION["info"];?></a></li> -->
			</ul>
			<!-- responsive -->
			<div class="nav-switch">
				<i class="fa fa-bars"></i>
			</div>
			<!-- Main Menu -->
			<ul class="main-menu">
				<li><a href="index.php"><i class="fa fa-lg fa-home"></i>&nbsp;Accueil</a></li>
				<!-- <li><a href="about.php"><i class="fa fa-lg fa-history"></i>&nbsp;Histoire</a></li> -->
				<li><a id="tags" href="tags.php"><i class="fa fa-lg fa-pie-chart"></i>&nbsp;Categories</a></li>
				<li class="active"><a href="movies.php"><i class="fa fa-lg fa-play"></i>&nbsp;Films</a></li>
				<!-- <li><a href="news.php"><i class="fa fa-lg fa-book"></i>&nbsp;News</a></li> -->
				<li><a href="contact.php"><i class="fa fa-lg fa-phone"></i>&nbsp;Contact</a></li>
				<li><a id="signin" href="signin.php"><i class="fa fa-lg fa-sign-in"></i>&nbsp;Se connecter</a></li>
                <li id="signup"><a href="signup.php"><i class="fa fa-lg fa-user"></i>&nbsp;S'inscrire</a></li>
                
                
			</ul>
			<div class="clearfix"></div>
			    
			</div><!-- container -->
			<!-- Social Links -->
			<!-- <div class="header-social-links">
				<a href="https://twitter.com/"><i class="fa fa-twitter"></i></a>
				<a href="https://soundcloud.com/"><i class="fa fa-soundcloud"></i></a>
				<a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
				<a href="https://plus.google.com/"><i class="fa fa-google-plus"></i></a>
				<a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
				<a href="https://www.youtube.com/"><i class="fa fa-youtube-play"></i></a>
			</div> -->
		</div>
	</header>
	<!-- Header section end -->

	<!--  section -->
	<section class="page-info-section set-bg" data-setbg="img/page-info-bg.jpg">
		<div class="container">
			<div class="section-title text-center">
				<h2>Tous les films</h2>
				<h4><?php echo $_SESSION["message"];?><h4>
			</div>
		</div>
	</section>
	<!--  section end -->
	
	<section class="story-area left-text center-sm-text pos-relative">

        <div class="container text-center">
            <div class="heading">
                <img class="heading-img" src="images/heading_logo.png" alt="">
                <h2 class="section-title text-center">À la carte</h2><br>
            </div>
        <?php
         
        $raw_results = $bdd->query("SELECT * FROM film") or die(mysql_error());
         
        if ($raw_results->rowCount() > 0){ 
             
            while($results = $raw_results->fetch(PDO::FETCH_ASSOC)){
            	echo "<img src='img/".$results['titre']."_review.jpg' style='width: 600px;'>";
                echo "<span style='color: white'><h3>".$results['titre']."</h3><h6>".$results['realisateur']."</h6><h6>".$results['duree']."</h6><br>".$results['resume']."</span><br><hr style='width: 700px; background-color: red;'><br>";
            }
        } else {
            echo "<img src='img/video-preview-bg.jpg' style='width: 500px;'>";
        	echo "<span style='color: white' class='section-title text-center'><h3>Aucun résultat</h3><h6>La médiathèque est vide</h6></span><br><hr><br>";
        }
?>
        </div><!-- container -->
</section>

	<!-- Footer Top section -->
	<section class="footer-top-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6 ft-widget">
					<div class="ft-title">
						<h4>Catégories</h4>
					</div>
					<ul class="order-list">
						<li><a href="tags.php?tagid=6"><span>AC</span>Action</a></li>
						<li><a href="tags.php?tagid=5"><span>FA</span>Famille</a></li>
						<li><a href="tags.php?tagid=2"><span>FF</span>Fantaisie</a></li>
						<li><a href="tags.php?tagid=4"><span>HO</span>Horreur</a></li>
						<li><a href="tags.php?tagid=3"><span>HU</span>Humour</a></li>
						<li><a href="tags.php?tagid=1"><span>SF</span>Science-Fiction</a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-6 ft-widget">
					<div class="ft-title">
						<h4>Top Films</h4>
					</div>
					<ul class="order-list">
						<li><a href="movies.php?filmid=1"><span>1</span>Aquaman</a></li>
						<li><a href="movies.php?filmid=2"><span>2</span>Venom</a></li>
						<li><a href="movies.php?filmid=3"><span>3</span>Bumblebee</a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-6 ft-widget">
					<div class="ft-title">
						<h4>News</h4>
					</div>
					<div class="ft-blog-widget">
						<div class="bw-item">
							<div class="bw-thumb set-bg" data-setbg="img/blog/thumb/1.jpg"></div>
							<div class="bw-content">
								<p>Films DC & Marvel</p>
								<a href="news.php">Lire plus</a>
							</div>
						</div>
						<div class="bw-item">
							<div class="bw-thumb set-bg" data-setbg="img/blog/thumb/2.jpg"></div>
							<div class="bw-content">
								<p>Coups de coeur et coups de gueule</p>
								<a href="news.php">Lire plus</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 ft-widget">
					<div class="ft-title">
						<h4>Contact</h4>
					</div>
					<div class="ft-contact-widget">
						<p><span>A:</span> 23, rue des Médias Film-sur-Scène</p>
						<p><span>T:</span> 06-23-12-1999</p>
						<p><span>E:</span> media@theque.com</p>
						<img src="img/logox2.png" style="width: 100px; clip-path: circle(50% at 50% 50%);">
						<img src="img/logox.png" style="width: 100px; clip-path: circle(50% at 50% 50%);">
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Footer Top section end -->

	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<p><!-- Lien de la template  -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> Tous droits réservés | Site fait avec <i class="fa fa-heart-o" aria-hidden="true"></i> par <a href="https://colorlib.com" target="_blank">MONDESIR Malik</a></p>
		</div>
	</footer>
	<!-- Footer section end -->

	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>
	<?php echo $change; ?>
    </body>
</html>
